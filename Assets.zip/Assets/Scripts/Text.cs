using UnityEngine;
using TMPro; // Namespace for TextMeshPro
using UnityEngine.SceneManagement; // Include this for scene management

public class GameManager : MonoBehaviour
{
    public int money = 0;
    public int energy = 3;

    public TextMeshProUGUI moneyText; // Reference to the TextMeshProUGUI component for money
    public TextMeshProUGUI energyText; // Reference to the TextMeshProUGUI component for energy

    void Start()
    {
        UpdateUI(); // Initial UI update
    }

    void UpdateUI()
    {
        moneyText.text = "Money: $" + money;
        energyText.text = "Energy: " + energy;
        CheckGameOver();
    }

    public void DeductEnergy()
    {
        if (energy > 0)
        {
            energy--;
            UpdateUI(); // Update the UI each time the energy changes
        }
    }

    void CheckGameOver()
    {
        if (energy <= 0)
        {
            LoadGameOverScene(); // Load the Game Over scene
        }
    }

    void LoadGameOverScene()
    {
        SceneManager.LoadScene("YouLose"); // Replace "GameOverScene" with the actual name of your game over scene
    }

    public void AddMoney(int amount)
    {
        money += amount;
        UpdateUI(); // Update the UI each time the money changes
    }
}
