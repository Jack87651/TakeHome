using UnityEngine;
using System.Collections; // Add this line to import the System.Collections namespace

public class SecurityGuardController : MonoBehaviour
{
    public float speed = 2.0f; // Speed at which the guard moves
    public float patrolDistance = 50f; // Distance the guard will patrol back and forth
    public Animator animator;
    public Rigidbody2D rb;

    private Vector2 startPos; // Starting position of the guard
    private bool movingRight = true; // Direction of movement
    private bool atEndPoint = false; // Indicates whether the guard reached the patrol distance


    void Start()
    {
        startPos = transform.position; // Record the starting position
    }

    void Update()
    {
        float distFromStart = Vector2.Distance(startPos, transform.position);

        // Check if reached the patrol distance and set atEndPoint
        if (distFromStart >= patrolDistance && !atEndPoint)
        {
            atEndPoint = true; // Reached patrol distance, flag to prevent multiple flips
            movingRight = !movingRight; // Change direction
            Flip(); // Flip the sprite when changing direction
        }

        // If moving back towards the start and previously reached the endpoint
        if (distFromStart < patrolDistance && atEndPoint)
        {
            atEndPoint = false; // Reset the endpoint flag as we move back
        }

        // Move the guard
        if (movingRight)
        {
            transform.position = new Vector2(transform.position.x + speed * Time.deltaTime, transform.position.y);
        }
        else
        {
            transform.position = new Vector2(transform.position.x - speed * Time.deltaTime, transform.position.y);
        }
    }

    public void StopMovement()
    {
        StartCoroutine(PauseThenResume());
    }

    IEnumerator PauseThenResume()
    {
        float originalSpeed = speed; // Store the original speed
        speed = 0; // Stop the guard by setting speed to zero
        animator.SetFloat("Speed", 0);
        rb.constraints = RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezePositionY | RigidbodyConstraints2D.FreezeRotation;

        yield return new WaitForSeconds(3); // Wait for 3 seconds

        // Resume movement
        rb.constraints = RigidbodyConstraints2D.FreezeRotation; // Unfreeze position but keep rotation frozen
        speed = originalSpeed; // Restore the original speed
    }

    void Flip()
    {
        // Flip the sprite by multiplying the x component of the local scale by -1
        Vector3 flipped = transform.localScale;
        flipped.x *= -1;
        transform.localScale = flipped;
    }
}
